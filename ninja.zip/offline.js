﻿{
	"version": 1651439534,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"tilemap.png",
		"hero_standart-sheet0.png",
		"hero_standart-sheet1.png",
		"hero_dzabudza-sheet0.png",
		"hero_dzabudza-sheet1.png",
		"hero_dzabudza-sheet2.png",
		"tiledbackground.png",
		"my_hp-sheet0.png",
		"my_hp_background-sheet0.png",
		"my_def-sheet0.png",
		"dzabudza_ultimate-sheet0.png",
		"energy-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"Photon-Javascript_SDK.min.js"
	]
}